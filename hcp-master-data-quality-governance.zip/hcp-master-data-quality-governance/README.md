# HCP Master Data Quality & Governance

**Portfolio project for a Commercial Data Management (CDM) internship**  
Author: **Chandra Varma Potharaju**

## Business question
Can commercial teams trust the healthcare-professional (HCP) master data used for segmentation, targeting and field outreach?

This project demonstrates a repeatable quality-control workflow for provider master data: completeness, validity, uniqueness, status checks and opt-out compliance.

## What is included
- `src/run_pipeline.py` — pandas validation pipeline and SQLite output.
- `sql/quality_checks.sql` — readable SQL checks for duplicates, missing fields, ZIP format and opt-out conflicts.
- `data/sample/` — small **synthetic demonstration data**. It is not real provider information.
- `reports/` — generated issue register, rule summary, SQLite database and run summary.
- `docs/data_dictionary.xlsx` — field definitions and business rules.

## Quick start
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/run_pipeline.py
```

To use another CSV extract:
```bash
python src/run_pipeline.py --hcp path/to/hcp.csv --optouts path/to/optouts.csv --outreach path/to/outreach.csv
```

The HCP CSV must contain: `npi, first_name, last_name, specialty, address, city, state, zip, phone, provider_status`. NPI values are kept as strings to preserve leading zeroes.

## Quality rules
| Rule | Check | Severity |
|---|---|---|
| DQ001 | Missing specialty | High |
| DQ002 | Missing address | High |
| DQ003 | ZIP not 5 digits or ZIP+4 | Medium |
| DQ004 | Phone does not contain 10 digits | Medium |
| DQ005 | NPI is not 10 digits | Critical |
| DQ006 | Duplicate NPI | High |
| DQ007 | Unexpected provider status | Medium |
| CMP001 | Opted-out HCP appears in outreach | Critical |

## Outputs
- `reports/data_quality_issues.csv` — row-level exception register.
- `reports/quality_summary.csv` — issue counts by rule and severity.
- `reports/hcp_quality.db` — SQLite tables for analysis.
- `reports/run_summary.txt` — execution summary.

## Demonstration findings
Run the pipeline to generate the actual counts from the included sample. The sample deliberately contains data-quality defects and opt-out conflicts so the checks can be demonstrated. **Do not present sample counts as real-world CMS findings.**

## Real CMS NPI data
The sample files are synthetic and intentionally small. For a real-data extension, download an NPPES monthly dissemination file from the official CMS NPPES page, select the required columns, and pass the prepared CSV to the pipeline. Follow the CMS data-use terms and avoid committing unnecessary personal or sensitive data to a public repository.

## Dashboard suggestion (Power BI)
Import `reports/quality_summary.csv` and `reports/data_quality_issues.csv`. Recommended visuals:
1. KPI cards: HCP rows processed, issue count, critical issues, opt-out violations.
2. Bar chart: issue count by rule.
3. Stacked bar: severity by rule.
4. Table: NPI, rule, severity and detail.
5. Trend line: issue counts across separately labelled monthly refresh snapshots.

A Power BI `.pbix` file is not included; these CSV/database outputs are ready to connect to Power BI.

## Limitations and responsible use
- The supplied provider and outreach rows are synthetic test records.
- The ZIP check validates format, not whether ZIP and state geographically match.
- The project uses NPI as the primary unique key; real cross-source entity resolution needs documented matching thresholds and manual review.
- The opt-out list is simulated solely to test compliance logic. It is not a real consent register.
- This is a portfolio demonstration, not a production compliance system.

## Next improvements
- Add official CMS NPPES ingestion and schema mapping.
- Add ZIP-to-state reference validation and address standardisation.
- Add monthly refresh snapshots and trend comparisons.
- Add unit tests, CI and a Power BI report.

## Suggested interview explanation
“I built a small HCP master-data quality framework that applies explicit business rules to provider records, logs exceptions with severity, and checks that a simulated opt-out population is excluded from outreach. The aim is to help commercial teams avoid poor targeting and prevent contact-data errors from reaching field operations.”
