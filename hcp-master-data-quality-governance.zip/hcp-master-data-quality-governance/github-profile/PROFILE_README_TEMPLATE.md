# Hi, I'm Chandra Varma Potharaju 👋

Electronics and Communication Engineering student at **NIT Andhra Pradesh**, interested in building practical solutions across **embedded systems, VLSI, and data-driven business operations**.

## About me
- 🎓 Electronics and Communication Engineering — NIT Andhra Pradesh
- 🔧 Embedded systems and hardware validation experience
- 💻 Exploring Python, SQL, data quality, and analytics
- 📚 Completed training in VLSI design and an NPTEL course in Internet of Things
- 🎯 Interested in embedded engineering, VLSI, and technology-enabled operations

## Skills
- **Programming & data:** Python, SQL, Pandas
- **Electronics:** Embedded systems fundamentals, microcontrollers, digital electronics
- **Tools:** MPLAB X IDE, Excel, Git, GitHub
- **Analytics:** Data cleaning, validation, business rules, reporting

## Featured project
### HCP Master Data Quality & Governance
A Python + SQL portfolio project demonstrating HCP master-data validation, duplicate detection, data-quality issue logging, and simulated opt-out compliance checks.

[View project repository](#) <!-- Replace # with the public repository URL after publishing. -->

## Connect
- LinkedIn: <!-- Add your LinkedIn profile URL -->
- Email: <!-- Add a professional email address -->

---
*I enjoy learning by building, testing, documenting, and improving practical projects.*
