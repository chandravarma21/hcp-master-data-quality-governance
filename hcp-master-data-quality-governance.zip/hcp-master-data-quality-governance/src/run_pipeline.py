"""Run HCP master-data quality checks against a CSV extract."""
from pathlib import Path
import argparse, sqlite3, re, pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = ["npi","first_name","last_name","specialty","address","city","state","zip","phone","provider_status"]

def validate(hcp, optouts, outreach):
    issues = []
    def add(mask, rule, severity, detail):
        for idx in hcp.index[mask.fillna(False)]:
            issues.append({"npi": str(hcp.loc[idx, "npi"]), "rule": rule,
                           "severity": severity, "detail": detail})
    add(hcp["specialty"].fillna("").astype(str).str.strip().eq(""), "DQ001_MISSING_SPECIALTY", "High", "Specialty is blank")
    add(hcp["address"].fillna("").astype(str).str.strip().eq(""), "DQ002_MISSING_ADDRESS", "High", "Address is blank")
    add(~hcp["zip"].astype(str).str.fullmatch(r"\d{5}(-\d{4})?"), "DQ003_INVALID_ZIP", "Medium", "ZIP must be 5 digits or ZIP+4")
    add(~hcp["phone"].astype(str).str.replace(r"\D","",regex=True).str.fullmatch(r"\d{10}"), "DQ004_INVALID_PHONE", "Medium", "Phone must contain 10 digits")
    add(hcp["npi"].astype(str).str.fullmatch(r"\d{10}").eq(False), "DQ005_INVALID_NPI", "Critical", "NPI must contain 10 digits")
    dup = hcp["npi"].astype(str).duplicated(keep=False)
    add(dup, "DQ006_DUPLICATE_NPI", "High", "NPI occurs more than once")
    add(~hcp["provider_status"].isin(["Active","Deactivated"]), "DQ007_INVALID_STATUS", "Medium", "Unexpected provider status")
    violations = set(optouts["npi"].astype(str)) & set(outreach["npi"].astype(str))
    for npi in sorted(violations):
        issues.append({"npi": npi, "rule":"CMP001_OPTOUT_IN_OUTREACH", "severity":"Critical",
                       "detail":"Opted-out HCP appears in marketing outreach"})
    return pd.DataFrame(issues, columns=["npi","rule","severity","detail"])

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--hcp", default=str(ROOT/"data/sample/hcp_sample.csv"))
    p.add_argument("--optouts", default=str(ROOT/"data/sample/synthetic_opt_outs.csv"))
    p.add_argument("--outreach", default=str(ROOT/"data/sample/marketing_outreach_sample.csv"))
    args=p.parse_args()
    hcp=pd.read_csv(args.hcp, dtype={"npi":str,"zip":str})
    optouts=pd.read_csv(args.optouts, dtype={"npi":str})
    outreach=pd.read_csv(args.outreach, dtype={"npi":str})
    missing=set(REQUIRED)-set(hcp.columns)
    if missing: raise ValueError(f"Missing required columns: {sorted(missing)}")
    issues=validate(hcp,optouts,outreach)
    out=ROOT/"reports"; out.mkdir(exist_ok=True)
    issues.to_csv(out/"data_quality_issues.csv",index=False)
    summary=(issues.groupby(["rule","severity"]).size().reset_index(name="issue_count")
             if not issues.empty else pd.DataFrame(columns=["rule","severity","issue_count"]))
    summary.to_csv(out/"quality_summary.csv",index=False)
    total=len(hcp); failed=hcp["npi"].astype(str).isin(set(issues.loc[issues.rule.str.startswith("DQ"),"npi"])) .sum()
    score=round(100*(1-len(issues[issues.rule.str.startswith("DQ")])/max(total,1)),1)
    with sqlite3.connect(out/"hcp_quality.db") as con:
        hcp.to_sql("hcp_master",con,if_exists="replace",index=False)
        optouts.to_sql("synthetic_opt_outs",con,if_exists="replace",index=False)
        outreach.to_sql("marketing_outreach",con,if_exists="replace",index=False)
        issues.to_sql("data_quality_issues",con,if_exists="replace",index=False)
    (out/"run_summary.txt").write_text(
        f"HCP rows processed: {total}\nData-quality issue rows: {len(issues)}\n"
        f"Distinct HCPs with data-quality issues: {failed}\n"
        f"Opt-out violations: {len(issues[issues.rule=='CMP001_OPTOUT_IN_OUTREACH'])}\n"
        f"Illustrative quality score: {score}%\n"
        "NOTE: Results are based on synthetic demonstration records, not real provider data.\n")
    print((out/"run_summary.txt").read_text())
if __name__=="__main__": main()
