-- HCP Master Data Quality & Governance
-- SQLite-compatible examples; run after loading the tables created by src/run_pipeline.py.

-- Duplicate NPIs
SELECT npi, COUNT(*) AS occurrences
FROM hcp_master GROUP BY npi HAVING COUNT(*) > 1;

-- Missing specialty / address
SELECT npi, 'missing specialty' AS issue FROM hcp_master
WHERE specialty IS NULL OR TRIM(specialty) = ''
UNION ALL
SELECT npi, 'missing address' FROM hcp_master
WHERE address IS NULL OR TRIM(address) = '';

-- Invalid ZIP codes (US ZIP / ZIP+4)
SELECT npi, zip FROM hcp_master
WHERE zip NOT GLOB '[0-9][0-9][0-9][0-9][0-9]'
  AND zip NOT GLOB '[0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]';

-- Opt-out compliance: must return zero rows before campaign release
SELECT o.npi
FROM synthetic_opt_outs o
INNER JOIN marketing_outreach m ON m.npi = o.npi;

-- Issue register
SELECT severity, rule, COUNT(*) AS issue_count
FROM data_quality_issues GROUP BY severity, rule
ORDER BY CASE severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END;
