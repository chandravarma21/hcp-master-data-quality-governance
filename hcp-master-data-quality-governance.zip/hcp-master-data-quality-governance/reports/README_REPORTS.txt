Generated demonstration outputs. All input records are synthetic; see root README for limitations.
